const logo = require('./logo.png');

export default {
  // app logo
  logo,
  home: {
    background: '#33AEAD'
  }
};
